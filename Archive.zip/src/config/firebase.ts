import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

// Firebase configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyDqhgg6bWPI-NEk-HOsVNhZrO3NRsSTTuU",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "squid-house.firebaseapp.com",
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL || "https://squid-house-default-rtdb.europe-west1.firebasedatabase.app/",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "squid-house",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "squid-house.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "975158330344",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:975158330344:web:5d23c02f83c01115e3da5d"
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);

